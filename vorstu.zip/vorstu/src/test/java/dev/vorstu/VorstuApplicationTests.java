package dev.vorstu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VorstuApplicationTests {

	@Test
	void contextLoads() {
	}

}
